<?php

if ( ! class_exists( 'MarkdownExtra_Parser' ) )
	jetpack_require_lib( 'markdown/extra' );

jetpack_require_lib( 'markdown/gfm' );
